
def name():
	return "sdk-serial"

def version():
    return "v0.1"