
name = "arjuno sdk-serial"

version = "0.0.1"