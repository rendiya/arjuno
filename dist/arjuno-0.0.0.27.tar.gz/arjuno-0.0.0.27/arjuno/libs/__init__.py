
name = "arjuno sdk-serial"

version = "v0.1"